import 'package:flutter/material.dart';
import 'package:flutter_application_2/data/list_item.dart';

class DetailScreen extends StatelessWidget {
  final item items;

  const DetailScreen({Key? key, required this.items}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<String> bahanImages = [
      'assets/bahan/ayam.png',
      'assets/bahan/bawang.png',
      'assets/bahan/cabai.png',
      'assets/bahan/cuka.png',
      'assets/bahan/daging.png',
      'assets/bahan/daunBawang.png',
      'assets/bahan/daunJeruk.png',
      'assets/bahan/ikan.png',
      'assets/bahan/jahe.png',
      'assets/bahan/kacang.png',
    ];

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          items.name,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 40,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      items.image1,
                      width: 300,
                      height: 300,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      items.image2,
                      width: 300,
                      height: 300,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      items.image3,
                      width: 300,
                      height: 300,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.asset('icons/waktu.png', width: 40, height: 40),
                Image.asset('icons/kalori.png', width: 40, height: 40),
                Image.asset('icons/harga.png', width: 40, height: 40),
              ],
            ),
            SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Deskripsi : ${items.tutorial}',
                maxLines: 15,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.brown,
                ),
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Bahan Racikan',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 8),
            Wrap(
              spacing: 8.0,
              runSpacing: 8.0,
              children: bahanImages.map((imagePath) {
                return ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.asset(
                    imagePath,
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
