class item {
  String name, bio, rp, tutorial, image, image1, image2, image3;

  item (
      {required this.name, required this.bio,
      required this.rp,
      required this.tutorial,
      required this.image, required this.image1, required this.image2, required this.image3});
}

List<item > dataItem  = [
  item (
      name: 'Bubur',
      bio: 'Bubur adalah makanan bertekstur lembut yang dibuat dari bahan dasar beras atau biji-bijian yang dimasak hingga hancur menjadi bubur.',
      rp: '10.000',
      tutorial:
          'Bubur adalah makanan bertekstur lembut yang dibuat dari bahan dasar beras atau biji-bijian yang dimasak hingga hancur menjadi bubur.',
      image1: 'bubur1.jpg',
      image2: 'bubur2.jpg',
      image3: 'bubur3.jpg',
      image: 'bubur.jpg'),
  item (
      name: 'Soto',
      bio: 'Soto adalah hidangan sup khas Indonesia yang terbuat dari kaldu daging, biasanya ayam atau sapi, dengan tambahan sayuran, bihun, dan bumbu rempah.',
      rp: '6.000',
      tutorial:
          'Bahan Racikan',
      image1: 'soto1.jpg',
      image2: 'soto2.jpg',
      image3: 'soto3.jpg',
      image: 'soto.jpg'),
  item (
      name: 'Pecel',
      bio: 'Pecel adalah makanan tradisional Indonesia berupa sayuran rebus yang disiram dengan sambal kacang yang gurih dan pedas.',
      rp: '8.000',
      tutorial:
          'Bahan Racikan',
      image1: 'pecel1.jpg',
      image2: 'pecel2.jpg',
      image3: 'pecel3.jpg',
      image: 'pecel.jpg'),

];
